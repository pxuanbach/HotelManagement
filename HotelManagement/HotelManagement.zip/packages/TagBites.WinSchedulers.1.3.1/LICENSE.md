# END-USER LICENSE AGREEMENT

Please, read this carefully. By using all or any portion of the Software you accept all the terms and conditions of this Agreement. If you do not agree, do not use this Software. 

1. This End-User License Agreement ("**Agreement**") is a legal contract between you (either (a) an individual user or (b) a business organization) ("**User**") and the Producer of the Computer Software ("**Producer**" - Tag Bites sp. z o.o.) including any associated media, printed materials and electronic documentation (the "**Computer Software**"). This License Agreement specifies the User's rights to use the Computer Software.

2. The Computer Software as well as the materials provided together with it are protected by Polish Copyright Law and international treaty provisions. The Producer owns full copyright to the Computer Software, and any person who infringes the copyright will be liable to civil and criminal proceedings. Under this License Agreement the Producer does not sell the Computer Software to the User. The Producer only empowers the User to perform the operations defined in the provisions of this Agreement. Performing operations not defined in the provisions of this Agreement requires written permission of the Producer.The powers of the User arising from this License Agreement become extinct if the User breaks any of its provisions. In such case the Producer will assert their rights specified by respective regulations within the largest scope possible.

3. **Restrictions to rights** The Producer permits the User to integrate the Computer Software in software being developed for the User ("User's Software") by 
one user in case of 'Single developer license' or unlimited number of users at single geographical location within a single company that purchased 'Company license'.
The User is given a limited, non-exclusive and non-transferable license to use the Computer Software in User's Software (including development, maintenance and operation of the User's Software), provided that:    
(a) User's Software adds primary and substantial functionality to the Computer Software,   
(b) all copies of the Computer Software must be exact and unmodified,  
(c) User grants User's Software end users a limited, personal, non-exclusive and non-transferable license to use the Computer Software only to the extent required for the permitted operation of User's Software and not to distribute them further.  
The User is not allowed:  
a) to transfer their rights arising from this License Agreement to third parties,  
b) to decompile the Computer Software or to modify it,  
c) to copy the printed materials provided together with the Computer Software,  
d) to create any software similar to the Computer Software, e) to remove nor change any trademarks or information about the Producer included in the Computer Software and the materials provided together with it.
	
4. **Evaluation version.** The Producer permits the User of the evaluation version to use the Computer Software on unlimited number of computers. The User is also allowed to make backup copies of the Computer Software. The User is not allowed to sell, let, rent nor lease these copies to third parties. The User may give the copies gratuitously if they ensure that the receiving party accepts the terms and conditions of this Agreement. The User is not allowed: a) to use the Computer Software for any other purpose than evaluation (this includes, but is not limited to, using the Computer Software for a commercial purpose), b) to create any software similar to or based on the Computer Software. 

5. User will reproduce along with the Computer Software all applicable trademarks and copyright notices that accompany the Computer Software, but you may not use Producer's name, logos or trademarks to market your products. 
Users give the Producer, without charge, the right to use your company name and logo on the Producer's customers list. 

6. **Limitation of Liability** The Producer does not warrant that the Computer Software will meet the expectations of the User or that it will properly cooperate with other Computer Software and programs. The Producer does not warrant either that the Computer Software will function without errors. If the User intends to use the Computer Software for any particular purpose, they accept full risk of the results they may obtain.  
The producer assumes no responsibility for any damages resulting from the use or impossibility to use the software. This provision concerns in particular loss and lost profits connected to any enterprise and loss or distortions of trade reference.  
The liability of the Producer under this Agreement shall be limited to the amount of US$1.00.

7. The Producer may collect and use technical information, gathered as part of support or other services provided to you related to the Computer Software, to improve our products or services or provide customized services or technologies to you. We may disclose this information to others, but not in a form that personally identifies you.